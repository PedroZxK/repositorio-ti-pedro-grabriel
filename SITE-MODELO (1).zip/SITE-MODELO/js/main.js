setTimeout(function() {
    document.body.style.display = "block";
    window.location.href ='sobre.html';
  }, 3000);
  
  document.body.style.display = "none";